#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <cstdlib>

#include "fun_glavni.h"
#include "fun.h"
#include "otvarac.h"

#include "CPolinom.h"

int main( int argc, char** argv )
{
    std::fstream datoteka = otvarac( *( argv + 1 ), "in" );

    std::vector<Polinom> polinomi;
    std::string linija;
    std::string prva_podniska;

    bool indikator = !datoteka.eof() && std::getline( datoteka, linija );
    while ( indikator )
    {
        std::istringstream strujanje_linije( linija );
        strujanje_linije >> prva_podniska;

        std::vector<double> niz = napravi_niz<double>( prva_podniska, strujanje_linije );
        polinomi.emplace_back( niz, niz.size() );

        indikator = !datoteka.eof() && std::getline( datoteka, linija );
    };

    PrintVektor< std::vector<Polinom> >( polinomi, true );

    std::vector<Polinom>().swap( polinomi );
    datoteka.close();

    return 0;
}
