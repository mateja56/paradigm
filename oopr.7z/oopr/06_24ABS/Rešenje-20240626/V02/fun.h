#include <iostream>

#include "fun1.h"

bool Citac( POZ *niz )
{
    bool indikator = true;

	for( POZ i = 0 ; i < 4 ; i++ ) indikator = indikator && std::cin >> *( niz + i );

    return indikator;
};

POZ najveci( POZ *niz )     // uzna je
{
    POZ max = *( niz + 0 );

    for( POZ i = 1 ; i < 4 ; i++ ) if( *( niz + i ) > max ) max = *( niz + i ) ;

    return max;
};

bool *mozda_blokira_tocak( POZ *niz )     // ruzna je
{
    bool *nadjeno = ( bool * )malloc( 4 * sizeof( bool ) );     // da se prisetimo ljubavi...

    POZ max_g = najveci( niz );           // najveca rotacija
    POZ max_d = max_g - max_g * 0.2;      // 20% najvece rotacije

    for( POZ i = 0 ; i < 4 ; i++ ) *( nadjeno + i ) = max_d <= *( niz + i ) && *( niz + i ) <= max_g;     // u zahtevanom intervalu

    return nadjeno;
};
