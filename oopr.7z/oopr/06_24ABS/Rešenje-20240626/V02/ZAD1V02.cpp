#include <iostream>

#include "fun1.h"
#include "fun.h"
#include "CKontrola.h"

int main( int argc, char **argv )
{
    POZ niz[4] = {0};
    bool *pniz, postoji_blokiran;

    bool indikator = !std::cin.eof() && Citac( niz );
    while( indikator )
    {
        Kontrola A( niz );     // treba ga seliti u 22 ili 23 ili 27
        A.Print( 1 );

        pniz = mozda_blokira_tocak( niz );
        postoji_blokiran = true;
        for( POZ i = 0 ; i < 4 ; i++ )
        {
            std::cout << *( pniz + i ) << " ";
            postoji_blokiran = postoji_blokiran && *( pniz + i );
        };
        std::cout << "-> " << postoji_blokiran;
        std::cout << std::endl;

        indikator = !std::cin.eof() && Citac( niz );
    };

    return 0;
}
