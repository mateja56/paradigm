typedef unsigned short int POZ;
